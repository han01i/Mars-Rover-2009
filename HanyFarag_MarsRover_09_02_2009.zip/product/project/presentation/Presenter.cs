using mars.rover.common;

namespace mars.rover.presentation
{
    public interface Presenter : Command
    {
    }
}