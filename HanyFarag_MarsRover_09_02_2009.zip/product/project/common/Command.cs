namespace mars.rover.common
{
    public interface Command
    {
        void run();
    }
}