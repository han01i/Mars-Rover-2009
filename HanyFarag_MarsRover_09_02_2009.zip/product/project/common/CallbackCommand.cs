namespace mars.rover.common
{
    public interface CallbackCommand<T> : ParameterizedCommand<T>
    {
    }
}